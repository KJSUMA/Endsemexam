package com.klef.jfsd.exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class LabExamApplication {
    public static void main(String[] args) {
        SpringApplication.run(LabExamApplication.class, args);
        System.out.println("Program is running..");
    }
}
